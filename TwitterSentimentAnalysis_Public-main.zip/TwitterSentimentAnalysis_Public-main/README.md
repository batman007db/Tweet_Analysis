# TwitterSentimentAnalysis_Public
Link : https://twitter-sentiment-analysis07.herokuapp.com/

- Our Goal will be to Create an API where the user will Enter a Topic, which we will search on Twitter and Extract tweets related to that Topic.
- We will then do sentiment Analysis on the extracted tweets and classify them into Positive, Negative, Neutral.
- Further, we will provide visualizations so the Data could be further analyzed by the user. 
- Here is a link to the Project i have Deployed, just so we are clear what we are working towards.


